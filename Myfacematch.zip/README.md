# facematch
Face match in python using Facenet and their pretrained model
